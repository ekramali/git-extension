import { JupyterFrontEndPlugin } from '@jupyterlab/application';
/**
 * Initialization data for the mybutton extension.
 */
declare const plugin: JupyterFrontEndPlugin<void>;
export default plugin;
